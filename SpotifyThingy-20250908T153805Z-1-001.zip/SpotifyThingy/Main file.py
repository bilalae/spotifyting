import numpy
import pandas
import matplotlib.pyplot as plt
from flask import Flask, request, jsonify, render_template
import json

app = Flask(__name__)


@app.route('/')
def index():
    return render_template("index.html")  # upload form


@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return "No file uploaded", 400

    file = request.files['file']

    # Read and parse JSON
    data = json.load(file)

    # Example: Process Spotify data
    # Replace this with your leftover Spotify analysis code
    result = {"track_count": len(data.get("tracks", []))}

    return jsonify(result)


if __name__ == "__main__":
    app.run(debug=True)
