from flask import Flask, request, render_template
import pandas as pd
import json
from datetime import datetime, timedelta

app = Flask(__name__)

#the API thing
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_files():
    if 'files' not in request.files:
        return "No files uploaded", 400

    #get timeframe: "30 days" "1 year" "lifetime"
    timeframe = request.form.get('timeframe', 'lifetime') #lifetime by default

    uploaded_files = request.files.getlist('files')
    dfs = []

    for file in uploaded_files:
        try:
            data = json.load(file)
        except Exception as e:
            return f"Error parsing {file.filename}: {str(e)}", 400

        if isinstance(data, dict):
            dfs.append(pd.DataFrame([data]))
        else:
            dfs.append(pd.DataFrame(data))

    AllHistory = pd.concat(dfs, ignore_index=True) #combining all the files together

    # Convert ms to minutes
    AllHistory['ms_played'] = AllHistory['ms_played'] / 60000

    # Convert timestamp
    AllHistory['ts'] = pd.to_datetime(AllHistory['ts']).dt.tz_localize(None)

    # Apply timeframe filter
    now = datetime.now()
    if timeframe == "30_days":
        cutoff = now - timedelta(days=30)
        AllHistory = AllHistory[AllHistory['ts'] >= cutoff]
    elif timeframe == "1_year":
        cutoff = now - timedelta(days=365)
        AllHistory = AllHistory[AllHistory['ts'] >= cutoff]
    #else: lifetime = no filter

    #Metrics
    amount_of_tracks = AllHistory['master_metadata_track_name'].count()
    total_listening_hours = AllHistory['ms_played'].sum() / 60
    avg_track_duration = AllHistory['ms_played'].mean()

    top_10_artists = AllHistory['master_metadata_album_artist_name'].value_counts().head(10)
    top_10_songs = AllHistory['master_metadata_track_name'].value_counts().head(10)

    return render_template('result.html',
                           timeframe=timeframe,
                           amount_of_tracks=amount_of_tracks,
                           total_listening_hours=total_listening_hours,
                           avg_track_duration=avg_track_duration,
                           top_10_artists=top_10_artists.to_dict(),
                           top_10_songs=top_10_songs.to_dict())

if __name__ == '__main__':
    app.run(debug=True)
